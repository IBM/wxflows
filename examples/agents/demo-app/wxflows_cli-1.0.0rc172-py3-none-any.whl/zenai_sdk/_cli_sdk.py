# Copyright IBM Corp. 2023, 2024

import json
import logging
import sys
from typing import Optional

from ._cli_clidata import CLIData
from .cli_error import CLIError
from .configuration import TOMLConfiguration
from .flows import execute_flow, execute_flow_databuild_utility
from .stepzen_services import StepzenLogin

logger = logging.getLogger("wxflows")


def cmd_sdk_execute(
    cli: CLIData,
    toml_data: TOMLConfiguration,
    flow_names: str,
    max_depth: Optional[int],
    json_data: Optional[str],
    var_data: Optional[str],
    var_file: Optional[str],
    graphql_query: Optional[str],
):
    logger.debug(f"sdk_execute with {flow_names} {max_depth} {json_data}")
    if len(flow_names) == 0 or flow_names[0] == "":
        raise CLIError("You must specify a flow")
    login = StepzenLogin(
        cli.account, cli.domain, cli.apikey, service_instances=cli.service_instance
    )
    endpoint_name = toml_data.endpoint_name()
    url = login.endpoint_uri(endpoint_name)
    data = execute_flow_databuild_utility(json_data, var_data, var_file)
    result = execute_flow(
        flow_names[0],
        data,
        max_depth=max_depth,
        endpoint_url=url,
        endpoint_apikey=cli.apikey,
        query=graphql_query,
    )
    logger.debug(f"sdk_execute returns {result}")
    # this should be the only thing written to stdout...
    print(json.dumps(result, indent=4))

    if "errors" in result and "data" not in result:
        print("You may use --var and --json to pass data into wxflows request", file=sys.stderr)
