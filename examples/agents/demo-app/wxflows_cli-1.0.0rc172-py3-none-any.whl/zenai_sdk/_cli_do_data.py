# Copyright IBM Corp. 2023, 2024
import asyncio
import csv
import io
import json
import logging
import math
import os
import time
import traceback
from importlib.util import find_spec
from typing import Any, Callable, Dict, List, Optional, Union

import aiofiles
import frontmatter
import tiktoken
from langchain.schema import Document
from langchain.text_splitter import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter
from langchain_text_splitters import HTMLHeaderTextSplitter

from ._cli_clidata import _get_vup
from ._cli_do import CLIData, _resolve_path
from ._cli_do_loader import build_reader_basic, model_info
from .cli_error import CLIError
from .configuration import _WATZENTOML, TOMLConfiguration
from .zenai_api import AsyncZenUpload

logger = logging.getLogger("wxflows")

model_aliases = {
    "mini": "all-MiniLM-L6-v2",
}


class Tokens:
    """
    estimates using tiktoken.
    """

    def __init__(self):
        self.tokenizer = tiktoken.get_encoding("cl100k_base")
        tiktoken.encoding_for_model("gpt-3.5-turbo")

    def token_count(self, text: str) -> int:
        """token_count returns the count of tokens by converting the text to
        token ids and returning the count
        """
        tokens = self.tokenizer.encode(text, disallowed_special=())
        return len(tokens)


class TSVWriter:
    """
    writer for title and content as TSV
    note: the path for id is not sufficient
    """

    def __init__(
        self,
        tsvfile: io.TextIOWrapper,
        tok: Tokens,
        out: Callable[[str], None],
        zup: Optional[AsyncZenUpload],
        url_column: str = "",
    ):
        self.writer = csv.writer(tsvfile, delimiter="\t", lineterminator="\n", escapechar="\\")
        self.idseq = 0
        cols = ["id", "title", "text"]
        self.url_column = url_column
        if url_column:
            cols.append(url_column)
        if zup:
            cols.append("embedding")
        self.writer.writerow(cols)
        self.counts = []
        self.tok = tok
        self.zup = zup
        self.out = out
        self.last_ts = time.time()
        self.embedding_time = 0.0

    async def write_title_content(self, title: str, text: str, url: Optional[str]):
        # todo refactor code so we batch up the compute embedding calls.
        id = self.idseq
        self.idseq += 1
        data: List[Union[int, str, List[float]]] = [id, title, text]
        if self.url_column:
            if url is None:
                raise CLIError("Missing url information")
            # note: for file reference in general
            # file scheme requires absolute paths which we don't want
            # here.
            # We can write the following as:
            # - file:///relativepath - which is misleading
            # - relativepath
            # which is allowed for URI/URLs
            # The choice for now is to use the relative path only
            data.append(url)
        if self.zup:
            content = title + "\n" + text if title else text
            # list of embeddings aligned with content
            start = time.time()
            emb = await self.zup.compute_embedding([content])
            if emb:
                data.append(emb[0])
            else:
                data.append([])
            self.embedding_time += time.time() - start
        self.writer.writerow(data)
        self.counts.append(self.tok.token_count(f"{title}\n{text}"))
        if (time.time() - self.last_ts) > 60:
            self.out(f"Processing... Last processed id: {id}")
            self.last_ts = time.time()

    async def close(self):
        logger.info(f"tsv: embedding took {self.embedding_time}")
        pass

    def stats(self):
        # probably should compute a histogram based upon chunks?
        dcnts = len(self.counts)
        if not dcnts:
            return {
                "description": "No data found.",
                "count": 0,
            }
        dcnts = dcnts if dcnts else 1
        return {
            "description": "Estimates of token counts based upon tiktoken embedding",
            "average": sum(self.counts) / dcnts,
            "min": min(self.counts),
            "max": max(self.counts),
            "sum": sum(self.counts),
            "count": len(self.counts),
        }


class MarkdownProcessor:
    def __init__(self, tok: Tokens, chunk_size: int, chunk_overlap: int):
        headers_to_split_on = [
            (str("#"), str("1")),  # make pyright happy
            ("##", "2"),
        ]

        # this will break things down by section first
        self.markdown_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=headers_to_split_on
        )

        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size, chunk_overlap=(chunk_overlap)
        )

    def split_text(self, content: str) -> List[Document]:  # FIX
        md_header_splits = self.markdown_splitter.split_text(content)
        return md_header_splits


async def processmd(
    filename: str, tok: Tokens, writer: TSVWriter, themd: str, chunk_size: int, chunk_overlap: int
):
    """
    process md data
    take title from the frontmatter if it exists
    """
    doc = frontmatter.load(themd)
    title = doc.get("title")
    mdp = MarkdownProcessor(tok, chunk_size, chunk_overlap)
    md_header_splits = mdp.split_text(doc.content)

    for frag in md_header_splits:
        text = str(frag.page_content)
        # must convert the chunk sizes back to tokens from characters
        splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
            encoding_name="cl100k_base",
            model_name="gpt-3.5-turbo",
            chunk_size=chunk_size / 4,
            chunk_overlap=chunk_overlap / 4,
        )
        chunks = splitter.split_text(text)

        title = doc.get("title", "")
        # heuristic to get best title; assume longest title
        # is best
        if doc.get("meta"):
            if (
                doc["meta"].get("title")
                and doc["meta"]["title"] != title
                and len(title) < len(doc["meta"]["title"])
            ):
                title = doc["meta"]["title"]
        if not title:
            title = frag.metadata.get("1") or ""
        # should check if overlap was enough
        for i in range(len(chunks)):
            title = title.replace("\n", " ")  # \n in title doesn't work well
            await writer.write_title_content(title, chunks[i], filename)


async def process_html(
    filename: str,
    tok: Tokens,
    writer: TSVWriter,
    data: str,
    chunk_size: int,
    chunk_overlap: int,
    data_type: str,
):

    # do we want h3?
    headers_to_split_on = [
        (str("h1"), str("1")),  # make pyright
        ("h2", "2"),
        ("h3", "3"),
    ]

    html_splitter = HTMLHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
    doclist = html_splitter.split_text(data)

    for document in doclist:
        # each "document" will be split on the 1,2,3 headings
        document.page_content
        # join all titles and level 2,3 headings to apply context
        title = document.metadata.get("1", "")
        metadata_context = "\n".join([document.metadata[x] for x in document.metadata if x != "1"])
        if metadata_context:
            metadata_context += "\n"
        mdl = len(metadata_context)
        if len(title) + mdl > (chunk_size - chunk_overlap):
            budget = (chunk_size - chunk_overlap) / 3
            # spend half the budget on the title, don't worry about tokens for now
            # or what happens if one or the other is missing
            if title:
                title = title[0 : min(len(title), int(budget / 2))]
            if metadata_context:
                metadata_context[0 : min(len(title), int(budget / 2))]
            logger.debug(
                f"Spend down budget {budget}, title {len(title)} context {len(metadata_context)}"
            )

        # now figure out the chunks but leave room for the document as well.
        use_chunk_size = chunk_size - mdl
        use_chunk_overlap = min(chunk_overlap, use_chunk_size)
        # must convert the chunk sizes back to tokens from characters
        splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
            encoding_name="cl100k_base",
            model_name="gpt-3.5-turbo",
            chunk_size=use_chunk_size / 4,
            chunk_overlap=use_chunk_overlap / 4,
        )
        chunks = splitter.split_text(document.page_content)

        # should check if overlap was enough
        for i in range(len(chunks)):
            title = title.replace("\n", " ")  # \n in title doesn't work well
            await writer.write_title_content(title, metadata_context + chunks[i], filename)


async def _mdhtmlprocess(
    out: Callable[[str], None],
    tok: Tokens,
    data_directory: str,
    data_type: str,
    output_file: str,
    chunk_size: int,
    chunk_overlap: int,
    zup: Optional[AsyncZenUpload],
    url_column: str = "",
    verbose: bool = False,
):
    out(f"Processing markdown or HTML in {data_directory} ({data_type})")
    logger.debug(f"_hdhtmlprocess: {chunk_size} {chunk_overlap}")
    with open(output_file, "w", newline="") as tsvfile:
        writer = TSVWriter(tsvfile, tok, out, zup, url_column=url_column)
        for root, dirs, files in os.walk(data_directory):
            for file in files:
                if not file.endswith(".md") and not file.endswith(".html"):
                    continue
                path = os.path.join(root, file)
                if verbose:
                    print(f"process {path}")
                if file.endswith(".md"):
                    await processmd(file, tok, writer, path, chunk_size, chunk_overlap)
                elif file.endswith(".html"):
                    async with aiofiles.open(path, "r") as f:
                        data = await f.read()
                        await process_html(
                            file, tok, writer, data, chunk_size, chunk_overlap, data_type
                        )
        await writer.close()
        out(json.dumps(writer.stats(), indent=4))


async def _autoprocess(
    out: Callable[[str], None],
    tok: Tokens,
    data_directory: str,
    data_type: str,
    output_file: str,
    chunk_size: int,
    chunk_overlap: int,
    zup: Optional[AsyncZenUpload],
    url_column: str = "",
):
    logger.debug(f"_autoprocess: {chunk_size} {chunk_overlap}")
    missing = []
    if not find_spec("unstructured"):
        missing.append("unstructured")
    if missing:
        print("error: missing imports", ", ".join(missing))
        raise Exception(
            "This feature requires langchain_community and unstructured which are not"
            " installed by default."
            " Install using the"
            ' command "pip install langchain_community unstructured[all-docs]"'
        )

    # wrap the import though the find_spec may be enough proection.
    try:
        # uses `unstructured` by default
        from langchain_community.document_loaders import DirectoryLoader  # pyright: ignore
    except Exception as e:
        raise Exception("A problem occured using langchain_community.document_loaders " + str(e))

    # now get down to work!
    loader = DirectoryLoader(data_directory)
    logger.debug(f"autoloading {data_directory}")
    docs = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,  # number of chars
        chunk_overlap=chunk_overlap,
        is_separator_regex=False,
    )
    logger.debug(f"writing {output_file}")
    with open(output_file, "w", newline="") as tsvfile:
        writer = TSVWriter(tsvfile, tok, out, zup, url_column=url_column)
        for doc in docs:
            fragments = text_splitter.create_documents([doc.page_content])
            for fragment in fragments:
                toks = fragment.page_content
                await writer.write_title_content(
                    "", toks, doc.metadata.get("source", json.dumps(doc.metadata))
                )
        await writer.close()
        print(json.dumps(writer.stats(), indent=4))
    pass


def cmd_data(
    console: Any,
    cli: CLIData,
    toml_data: TOMLConfiguration,
    command: str,
    args: Dict[str, Union[str, int]],
    force: bool = False,
    emit_command=False,
):
    """
    processes incoming files from "data_directory" and creates
    columnar output (tsv) recorded into the first entry
    the tsv_files entry of the toml (watson.toml).

    The process will read the incoming file and break it down
    into (overlapping) chunks

    The size of chunks is dependent upon the embedding model where we
    want the number of tokens to align with the embedding model's
    limit on tokens.  However, as a simplification and reduction of
    requirements imposed on the user, the embedding model is not used
    directly in this phase and instead tiktoken is used to estimate
    the number of tokens in the fragment.

    The embedding can be pre-computed in this phase if
    `compute-embeddings` is set and is based upon the `content`
    column.  This can only be done using an `ai_engine`.  The
    `ai_engine` and `model` must be present in the toml.
    """

    def out(msg: str):
        """wrap this"""
        console.print(msg)

    output_directory = toml_data.toml_location()
    tsv_files = toml_data.pattern_tsv_files()
    model = toml_data.pattern_embedding_model()
    logger.debug(f"data load: od '{output_directory}' tsv_files {tsv_files} model {model}")
    tok = Tokens()

    # get arguments from args first, toml second
    data_directory_arg = args.get("data_directory", toml_data.pattern_data_directory())
    data_type_arg = args.get("data_type", toml_data.pattern_data_type())
    chunk_size_arg = args.get("chunk_size", toml_data.pattern_chunk_size())
    chunk_overlap_arg = args.get("chunk_overlap", toml_data.pattern_chunk_overlap())

    # get around some type check issues [ugly]
    if data_directory_arg is not None and isinstance(data_directory_arg, int):
        raise Exception("Internal error: data_directory_arg is not a string")
    if chunk_size_arg is not None and not isinstance(chunk_size_arg, int):
        raise Exception("Internal error: chunk_size is not an int")
    if chunk_overlap_arg is not None and not isinstance(chunk_overlap_arg, int):
        raise Exception("Internal error: chunk_overlap is not an int")

    # eventually data will part of the deploy chain so use the command to
    # determine if we are in deploy or data.
    if not data_directory_arg:
        if command == "build":
            raise CLIError("The data-directory must be specified for the data build command")
        return
    else:
        data_directory: str = data_directory_arg

    amodel = model_aliases.get(model, model)
    # this information is currently hardcoded, but later:
    # call the API to get this information
    lmodel_information = [mi for mi in model_info if mi["name"] == amodel]
    if len(lmodel_information) != 1:
        raise CLIError("Unknown or bad model: " + model)
    model_information = lmodel_information[0]
    max_chunk_size = model_information["maxSeqLen"]

    # default value are set here so we can determine if the argument was set
    # (and overrides the toml)
    chunk_size: int = max_chunk_size
    if chunk_size_arg is not None:
        chunk_size = chunk_size_arg
    chunk_overlap: int = int(chunk_size / 2.0)  # 1/2 chunk_size
    if chunk_overlap_arg is not None:
        chunk_overlap = chunk_overlap_arg

    logger.debug(
        f"data load: data {data_directory_arg} type {data_type_arg} chunking {chunk_size} {chunk_overlap}"
    )

    data_type: str = "md"
    if data_type_arg is not None:
        data_type = str(data_type_arg)

    if chunk_size > max_chunk_size:
        raise CLIError(f"chunk size must be less than {max_chunk_size}")
    if chunk_overlap > chunk_size:
        raise CLIError(
            f"The chunk overlap ({chunk_overlap}) must be less than the chunk size ({chunk_size})"
        )

    if not tsv_files:
        print(f"no (output) tsv file location, either edit your {_WATZENTOML} or re-init")
        return
    if len(tsv_files) > 1:
        raise CLIError("multiple tsv files not supported in this mode")

    tsv_file = _resolve_path(tsv_files[0], output_directory)
    if os.path.exists(tsv_file):
        if force:
            print(f"force overwrite of {tsv_file}")
        else:
            if emit_command:
                print(f"Will not overwrite {tsv_file}.")
                extras = "--force"
                if args.get("compute_embeddings"):
                    extras = "--compute-embeddings " + extras
                if data_type_arg:
                    extras = f"--data-type {data_type_arg} " + extras
                if chunk_size_arg:
                    extras = f"--chunk-size {chunk_size_arg} " + extras
                if chunk_overlap_arg:
                    extras = f"--chunk-overlap {chunk_overlap_arg} {extras}"
                print("To force the output TSV file to be overwritten, run this: ")
                print("   ", f"wxflows data build --data-directory {data_directory} {extras}")
            else:
                print(
                    f"Will not overwrite {tsv_file}.  Use --force to force the file to be overwritten."
                )
            return

    if os.path.dirname(tsv_file) and not os.path.exists(os.path.dirname(tsv_file)):
        logger.debug(f"creating directory {os.path.dirname(tsv_file)} for {tsv_file}")
        os.makedirs(os.path.dirname(tsv_file))

    zup = None
    if args.get("compute_embeddings"):
        zup = _get_vup(cli, toml_data, cli.account_domain, "data")
        out("Computing embeddings, this will take some time...")

    url_column = str(args.get("url_column", ""))
    if url_column:
        logger.debug(f"url_column {url_column}")

    # chunk_size and chunk_overlap are in tokens, convert to characters HERE.
    with console.status("Processing documents..."):
        if data_type == "auto":
            asyncio.run(
                _autoprocess(
                    out,
                    tok,
                    data_directory,
                    data_type,
                    tsv_file,
                    chunk_size * 4,
                    chunk_overlap * 4,
                    zup,
                    url_column=url_column,
                )
            )
        elif data_type == "md" or data_type.startswith("html"):
            asyncio.run(
                _mdhtmlprocess(
                    out,
                    tok,
                    data_directory,
                    data_type,
                    tsv_file,
                    chunk_size * 4,
                    chunk_overlap * 4,
                    zup,
                    url_column=url_column,
                )
            )
        else:
            raise CLIError(f"Unknown type {data_type}")


async def _annotate_data(
    out: Callable[[str], None],
    directive: str,
    model: str,
    files: List[str],
    output_file: str,
    zup: Optional[AsyncZenUpload],
):
    combine = directive == "combine-text" or directive == "convert-text"
    deleteold = directive == "convert-text"

    ndocs = 500
    rdr = build_reader_basic(files, ndocs, combine, deleteold)
    call_limit = zup.call_limit if zup and zup.call_limit else ndocs
    header = True

    start_time = time.time()
    last_ts = time.time()
    count = 0
    async for batch in rdr(ndocs):
        if model and zup:
            enc = []
            content = batch.to_dict(orient="records")
            ncontent = len(content)
            embeds = math.ceil(ncontent / call_limit)
            logger.debug(
                f'Batch size {ncontent} embedding calls {embeds} lastid {content[ncontent-1]["id"]}'
            )
            for i in range(embeds):
                l = min((i + 1) * call_limit, ncontent)
                partial: List[str] = [content[j]["content"] for j in range(i * call_limit, l)]
                penc = await zup.compute_embedding(partial, model)
                if penc is None:
                    raise Exception("Unexpected failure while computing embeddings")
                enc.extend(penc)
            batch["embedding"] = enc
            count += len(enc)
            if (time.time() - last_ts) > 60:
                out(f"Processing... {count}")
                last_ts = time.time()
        batch.to_csv(output_file, sep="\t", mode="a", index=False, header=header)
        header = False  # only first time.
    total_time = time.time() - start_time
    out(f"annotation process took {total_time}")


def cmd_data_annotate(
    console: Any,
    cli: CLIData,
    toml_data: TOMLConfiguration,
    directive: str,
    model: str,
    files: List[str],
    output_file: str,
    force: bool = False,
):
    """
    annotate existing columnar data (tsv) with `embedding`

    take a second look at the command structure
    directive:
    - content - create content from text and title
    - content-remove-sources - same as content, but remove text + title

    this sits to the side of all other commands for now.
    """

    def out(msg: str):
        """wrap this"""
        console.print(msg)

    if os.path.exists(output_file):
        if force:
            os.remove(output_file)
        else:
            raise CLIError(
                f"{output_file} exists will not overwrite.   use --force or remove the file first"
            )
    zup = None
    if model:
        zup = _get_vup(cli, toml_data, cli.account_domain, "data")
        out(f"Computing embeddings using {model}, this may take some time...")
    else:
        out(
            "No model provided so will skip encoding embeddings [will not default to the model in watson.toml]"
        )
        # return  # for now, since command is not provided

    with console.status("Annotating data..."):
        try:
            asyncio.run(_annotate_data(out, directive, model, files, output_file, zup))
        except Exception as e:
            logger.debug(f"Exception while annotating data {e}")
            logger.debug(f"{traceback.format_exc()}")
            console.print(f"Exception: {e}")
            raise CLIError(f"Exception while annotating data {e}")
