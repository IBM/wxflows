# Copyright IBM Corp. 2023, 2024
import collections
import copy
import json
import logging
import os
import sys
import time
from typing import Any, Dict, List, Mapping, Optional, Tuple, Union
from urllib.parse import urljoin, urlparse, urlunsplit

import yaml
from dateutil.parser import parse as dateparser
from gql import Client, gql
from gql.transport.exceptions import TransportQueryError
from gql.transport.httpx import HTTPXAsyncTransport
from httpx import AsyncHTTPTransport, ConnectError

logger = logging.getLogger("wxflows")


def _prefix_allows_env_substitution(k: str) -> bool:
    """returns true if `k` is allowed to be replaced by env variable k
    e.g. replace STEPZEN_X with os.environ["STEPZEN_X"]"""
    return k.startswith("STEPZEN_") or k.startswith("WATSONX_")


class StepzenConfig:
    """

     StepzenConfig - we refer to the entire configuration for
     stepzen as configuration and it is typically in a config.yaml
     file.   At one, it only held configuration to be used by
     the stepzen endpoint's.

     over time, this has evolved and this configuration actually consists
     of of various endpoint configuration for both the user and the system.

     The full `Configuration` consists of
     Configuration:
       configurationset: [Configurationset!]
       access: Policies*
       deployment: DeploymentSettings*

      Eventually allow access, deployment to be specified/accessed.

    The configurationset is what is used by the endpoints.
    We currently only allow 1 configurationset as we found
     having multiple caused confusion and mixed semantics
     (if the same configuration exists in both, which wins?).
    Each configuration consists of a *named* list of key value
     pairs.   For `config.yaml` readability purposes, the name
     was specified as a key-value pair.
    The endpoint itself will refer to the named configuration
     and then specific key/value pairs.

    Effectively:
     Configurationset:
       - configuration
          - name: NAME
          - key: value

    Finally, it was a commmon request that the value ought to be a value
    that could be pulled from a .env file.

    To match the `stepzen` cli functionality, we replace any _value_
    that starts with `STEPZEN_` with it's environment value
    if that env key exists.
    NOTE: we may want to allow other prefixes, etc.   The specific way
    this was done was as a backward compatability for existing stepzen
    cli users.
    """

    def __init__(
        self, data: Optional[Dict[str, Any]], env: Mapping[str, Optional[str]] = os.environ
    ):
        """
        note: added the notion we needed "raw" original data later.
        definitely some cleanup possible.
        """
        if not data:
            data = {"configurationset": []}

        # get rid of bool and nils
        for config in data.get("configurationset", {}):
            for k, v in config["configuration"].items():
                item = config["configuration"][k]
                if item is None:
                    config["configuration"][k] = ""
                elif isinstance(item, bool):
                    config["configuration"][k] = "true" if item else "false"
        self.data = data
        self.env = env
        pass

    def get_configuration_file(self) -> str:
        # reformat the self.data into yaml
        data = copy.deepcopy(self.data)
        cs = data["configurationset"]
        for item in cs:
            # clean this up?
            configuration = item["configuration"]
            ordered = (
                ["name"]
                + [
                    name
                    for name in configuration
                    if name != "name" and not name.startswith("stepzen.")
                ]
                + [name for name in configuration if name.startswith("stepzen.")]
            )
            oc = collections.OrderedDict({name: configuration[name] for name in ordered})
            item["configuration"] = oc

        def ordered_dict_yaml(dumper, data):
            return dumper.represent_dict(data.items())

        yaml.add_representer(collections.OrderedDict, ordered_dict_yaml, Dumper=yaml.SafeDumper)
        return yaml.safe_dump(data)

    def subs(self, data: str) -> Tuple[str, bool]:
        """allowed subs; stick to stepzen for now.
        returns str and true if changed"""
        if not _prefix_allows_env_substitution(data):
            return data, False
        if data in self.env:
            result = self.env.get(data, "")
            if result is None:  # make pyright happy
                result = ""
            return result, True
        return data, False

    def add(
        self, name: str, configurationset_configuration: Dict[str, str], report_new: bool = True
    ):
        """add takes the configurationset_configuration and adds
        configuration provides a named configuration.  The configuration consists
        of a series of key, value pairs.   If the configuration already exists,
        then it will be merged with this configuration.  Any existing keys may
        be overwritten.

        """

        # data should be clean in config
        # and is expected to be clean on in the incoming side?
        def cleaner(data):
            if data is None:
                return ""
            elif isinstance(data, bool):
                return "true" if data else "false"
            return data

        # we rewrite the incoming data so make a copy first
        # this will be add to existing configuration set so no longer
        # can get original.
        safe = copy.copy(configurationset_configuration)
        safe["name"] = name
        merged = False
        for config in self.data.get("configurationset", {}):
            cname = config.get("configuration", {}).get("name", "")
            if cname == name:

                # changed if new key or changed value
                possibles = [
                    k
                    for k in config.get("configuration")
                    if k not in safe.keys()
                    or cleaner(safe.get(k)) != cleaner(config.get("configuration", {}).get(k))
                ]
                if any(possibles):
                    # should we clean values?
                    config.get("configuration", {}).update(safe)
                    logger.debug(
                        f'merging {name} to configuration {config.get("configuration").keys()} {safe.keys()}'
                    )
                # really means name was seen
                merged = True
        if not merged:
            if report_new:
                logger.debug(f"appending {name} to configuration")
            self.data.get("configurationset", []).append({"configuration": safe})

        pass

    def cleanup(self, configuration: Dict[str, Any]) -> Dict[str, str]:
        """
        configuration must be Dict[str,str] but yaml doesn't know this
        so things like "true", null  must be converted to our string
        equivalents.
        also apply the env substitution
        will edit in place, so make a copy first
        """
        config = {}
        possible = 0
        config_name_d = []
        env_name_d = []

        for k in configuration:  # should iteritems this.
            data = configuration[k]
            if data is None:
                config[k] = ""
            elif isinstance(data, bool):
                config[k] = "true" if data else "false"
            elif isinstance(data, str):
                if _prefix_allows_env_substitution(data):
                    possible += 1
                    config[k], changed = self.subs(data)
                    if changed:
                        config_name_d.append(k)
                        env_name_d.append(data)
                else:
                    config[k] = data
            else:
                config[k] = f"{data}"
        # put in some tracking information
        replace_info = {}
        if len(config_name_d):
            replace_info.update(
                {
                    "counts": {
                        "env.updated": len(config_name_d),
                        "env.prefixed": possible,
                        "config.total": len(config),
                    }
                }
            )
            # careful with config names as they can be arb. unicode.
            replace_info.update({"config": config_name_d, "env": env_name_d})
            if replace_info:
                config["stepzen.config.1"] = json.dumps(replace_info)
        return config

    def get_configuration(self) -> Dict[str, Any]:
        # do edits on a copy, less efficent, but..
        data = copy.deepcopy(self.data)
        cs = data["configurationset"]
        for item in cs:
            configuration = item["configuration"]
            item["configuration"] = self.cleanup(configuration)
        return data

    def set_value(self, key: str, value: Dict[str, Any]):
        """used for access policy, etc."""
        # limit?
        self.data[key] = value
        logger.debug(f"configuration: set_value {key}")

    def get_configuration_env(self) -> List[str]:
        cs = self.data["configurationset"]
        items = []
        for item in cs:
            configuration = item["configuration"]
            items.extend(
                [
                    configuration[k]
                    for k in configuration
                    if isinstance(configuration[k], str)
                    and _prefix_allows_env_substitution(configuration[k])
                ]
            )
        return list(set(items))


class StepzenConfigYaml(StepzenConfig):
    """
    from config.yaml
    """

    def __init__(self, file_name: str, env: Mapping[str, Optional[str]] = os.environ):
        with open(file_name, "r") as f:
            data = yaml.safe_load(f)
            super(StepzenConfigYaml, self).__init__(data, env)


def form_introspection(s: Optional[str]):
    """
    introspection reference can be http://hostname  or https://hostname or https://hostname/path
    """
    if not s:
        return "https://stepzen-introspection.us-east-a.ibm.stepzen.net/api/graphql"
    theurl = urlparse(s)
    if not theurl.scheme:
        raise RuntimeError("not a valid URL")
    # path may be `/` but we should respect that?
    if theurl.path:
        return s
    return urljoin(theurl.geturl(), "api/graphql")


class StepzenLogin:
    """
    holds login information

    The StepZen config has three cases:
    - old stepzen.net
    - service_instances - for zenctl2 server (api connect)
      - fixed introspection
    - service_instances - for local *and* onpremise
      - local/onpremise introspection

    Note we must allow *any* domain for on-premise.

    """

    def __init__(
        self,
        account: str,
        domain: str,
        admin_apikey: str,
        introspection: Optional[str] = "",
        account_apikeys: List[str] = [],
        service_instances: Optional[Dict[str, str]] = None,
        debug_url: str = "",
    ):
        self.account = account
        self.domain = domain
        self.admin_key = admin_apikey

        # setup for the first one
        if len(account_apikeys) > 0:
            self.account_apikey = account_apikeys[0]
        else:
            self.account_apikey = ""

        if domain in ("stepzen.net", "stepzen.io", "eu.stepzen.io", "eu.stepzen.net"):
            logger.debug("No GCP stepzen")
            # todo: change over exception
            raise RuntimeError(
                "Flows Engine services are not available in the GCP version of stepzen"
            )
        if self.domain == "":
            raise RuntimeError(
                "internal error: the domain your environment uses could not be determined, this is usually a configuration issue"
            )

        # we can only get here with zenctl2 which has serviceinstance.zenctl2 minimally

        if not service_instances:
            if not domain:
                service_instances = {
                    "zenctl2": "https://stepzen.us-east-a.ibm.stepzen.net/api/zenctl/__graphql",
                    "introspection": "https://stepzen-introspection.us-east-a.ibm.stepzen.net/api/graphql",
                }
            else:
                # good enough for now?
                service_instances = {
                    "zenctl2": f"https://stepzen.{domain}/api/zenctl/__graphql",
                    "introspection": f"https://stepzen-introspection.{domain}/api/graphql",
                }

        self.zenctl2 = service_instances.get("zenctl2")
        # introspection is allowed to be a hostname and a few other cases.
        if introspection:
            self.introspection = form_introspection(introspection)
        else:
            self.introspection = form_introspection(service_instances.get("introspection"))

        logger.info(f"StepzenLogin: Introspection {self.introspection} zenctl: {self.zenctl2}")
        if debug_url:
            self.introspection = f"{debug_url}/api/graphql"
            self.zenctl2 = f"{debug_url}/api/zenctl/__graphql"
            logger.info(
                f"StepzenLogin: OVERRIDE Introspection {self.introspection} zenctl: {self.zenctl2}"
            )

        self.as_stepzen_service = False
        self.self_host = ""  # no self
        # consider revising upstream once GCP services are cleared out to clean up domain
        # self_host and self_port are "domain" which for non-GCP is the netloc/authority
        if service_instances and self.zenctl2 and self.islocalhost(self.domain):
            self.as_stepzen_service = True
            urlinfo = urlparse(self.zenctl2)
            logger.debug(f"local: API Connection Essentials using stepzen services {self.domain}")
            # 127.0.0.1, ::1 (not [::1])
            self.self_host = urlinfo.hostname
            self.self_port = urlinfo.port
        pass

    INTROSPECTION_STAGING = "use-steprz-introspection"

    def edit(self, tag):
        if tag == self.INTROSPECTION_STAGING and self.introspection:
            self.introspection = self.introspection.replace("stepzen.net", "steprz.net")
            logger.debug(
                f"Updated introspection endoint to steprz.net to usestaging: {self.introspection}"
            )

    @staticmethod
    def islocalhost(dom) -> bool:
        if dom.startswith("127.0.0.1"):
            return True
        if dom == "[::1]" or dom == "[0:0:0:0:0:0:0:1]":
            return True
        if dom == "localhost":
            return True
        return False

    def endpoint_uri(self, endpoint_name: str, docker_hostname_preferred: bool = False) -> str:
        """retrieve endpoint uri given  a name"""
        logger.info(f"{self.domain}")
        if self.as_stepzen_service:
            # only a single account "graphql"
            return f"http://{self.domain}/{endpoint_name}/graphql"
        return f"https://{self.account}.{self.domain}/{endpoint_name}/graphql"

    def __str__(self):
        return f"{self.account} {self.domain} {self.zenctl2} {self.introspection} length admin key {len(self.admin_key)} api key {len(self.account_apikey)}"


class SchemaFileData:
    def __init__(self, name: str, content: str):
        self.name = name
        self.content = content
        pass

    def __str__(self):
        return f"{self.name} content length {len(self.content)}"

    def get(self):
        return {"name": self.name, "content": self.content}

    def extend(self, content: str):
        """extend content"""
        self.content += "\n" + content


# rename this to schemafiles?
class EndpointSchema:
    """
    Schema for a StepZen GraphQL endpoint which maps to
    the `SchemaFilesInput` GraphQL object.

    input SchemaFilesInput {
      files: [SchemaFileInput!]!
      entryPoint: String
    }

    input SchemaFileInput {
      name: String!
      content: String!
    }

    NYI - the entryPoint is not handled
    """

    def __init__(self, sdl: List[SchemaFileData]):
        self.sdl = sdl  # index

    def index(self) -> Optional[SchemaFileData]:
        for sdl in self.sdl:
            if sdl.name == "index.graphql":
                return sdl
        return None

    def entry(self):
        """hard code entry name"""
        return "index.graphql"

    def find(self, sf: SchemaFileData) -> Optional[SchemaFileData]:
        """find the specifiedsSchemaFileData by name"""
        for sdl in self.sdl:
            if sdl.name == sf.name:
                return sdl
        return None

    def add(self, sf: SchemaFileData):
        # also must add a reference to this in the index
        index = self.index()  # find the index
        # ignore double appends
        self.sdl.append(sf)
        # ignore issue of directory names, etc.
        user_extension_file = sf.name
        logger.info(f"EndpointSchema: adding {str(sf)}")
        if index:
            index.extend(f'extend schema @sdl( files: "{user_extension_file}")')

    def add_noindex(self, sf: SchemaFileData):
        self.sdl.append(sf)
        logger.info(f"EndpointSchema: adding {str(sf)} - skipping adding to index")

    def schema_files(self) -> Dict[str, List[Dict[str, str]]]:
        data = []
        index = self.index()
        if not index:
            logger.debug("endpoint schema without index.graphql")
            raise RuntimeError("no index.graphql found. root is not known")
        for sdl in self.sdl:
            data.append(sdl.get())
        return {"files": data}


class StepzenDeployResult:
    """
    deploy
    """

    def __init__(self, result: Dict[str, Any], domain: str):
        endpoints = result.get("endpoints")
        self.domain = domain
        self.endpoints = []
        if not endpoints or len(endpoints) < 1:
            return
        # practically, there will be only one
        endpoint = endpoints[0]

        self.account = endpoint["account"]
        self.endpoint_name = f'{endpoint["folderName"]}/{endpoint["endpointName"]}'
        self.created_at = dateparser(endpoint["createdAt"])
        self.updated_at = dateparser(endpoint["updatedAt"])

        # ignore these for now.
        self.public = endpoint.get("public")
        self.deployment_type = endpoint.get("deploymentType")
        logger.debug(f"stepzendeploy result: {json.dumps(result)} {domain}")

    def __str__(self):
        return f"{self.account} endpoint {self.endpoint_name} created {self.created_at} updated {self.updated_at}"

    def endpoint_uri(self) -> str:
        """retrieve endpoint uri given  a name"""
        return f"https://{self.account}.{self.domain}/{self.endpoint_name}/graphql"


def report_transport_error(
    e: TransportQueryError, noPrint: bool = False, reportLocation: bool = True
):
    """
    noPrint is for cases like validate where we don't want errors to show
    reportLocation is for introspection where the location won't make sense to anyone
      since it's all intenral.
    """
    if e.errors:
        for err in e.errors:
            if not noPrint:
                print("  Message: ", err.get("message"), file=sys.stderr)
                if reportLocation:
                    print("  Location: ", err.get("locations"), file=sys.stderr)
            logging.debug(f'  Message {err.get("message")}')
            logging.debug(f'  Location {err.get("locations")}')

    if e.extensions:
        logging.debug(f"  Extensions:\n{e.extensions}")
        if not noPrint:
            print("{e.extensions}", file=sys.stderr)


class StepzenServices:
    """
    calls to stepzen zenctl2
    - depending on end to end testing for this for now.
    """

    def __init__(self, login: StepzenLogin):
        self.login = login
        headers = {}
        if not login.zenctl2:
            raise RuntimeError("internal error: Missing zenctl2 address")
        httpx_transport = AsyncHTTPTransport(retries=3)
        logger.debug(f"stepzen services: initialized {login.zenctl2}")
        transport = HTTPXAsyncTransport(
            url=login.zenctl2, headers=headers, transport=httpx_transport
        )
        self.transport = transport
        logger.debug(f"stepzen services result: {str(self.login)}")

    def endpoint_uri(self, endpoint_name: str) -> str:
        """endpoint uri"""
        return self.login.endpoint_uri(endpoint_name)

    async def validate(self) -> List[str]:
        query = gql(
            """
query ( $account: String! $adminKey: String! $deploymentType: String! ) {
        accounts: account(account: $account adminkey: $adminKey deploymentType: $deploymentType )
 { account_deployment_type account_name account_owner_email key_value_api } }"""
        )
        account = self.login.account
        admin_key = self.login.admin_key
        gql_vars = {"account": account, "adminKey": admin_key, "deploymentType": "local"}
        logger.debug("stepzen services validate")
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)
        except TransportQueryError as e:
            report_transport_error(e, noPrint=True)
            raise
        logger.debug(f"zenctl: validate {time.time() - start}")
        if not result or "accounts" not in result:
            logger.debug(f"Failure {result}")
            raise RuntimeError("validation of environment {account} failed")
        accounts = result.get("accounts")
        if not accounts:
            raise RuntimeError(f"validation of the environment {account} failed")

        # paranoid check makes vcr difficult
        # if not any([acc["account_name"] == account for acc in accounts]):
        #    raise RuntimeError("validation of account failed")

        if len(accounts) < 1:
            raise RuntimeError(f"validation of environment {account} failed")
        # there need not be an APIKey but that's likely what we want.
        # comes back as a string...
        return json.loads(accounts[0].get("key_value_api", "[]"))

    async def remove_endpoint(self, endpoint_name: str) -> str:
        # NOTE: the server side allows non-legal endpoints to be added / removed for now.
        parts = endpoint_name.split("/")  # check for validity?
        query = gql(
            """mutation removeEndpoint($account: String!, $deploymentType: String!, 
   $folderName: String!, $endpointName: String!, $adminkey: String!) {
        removeEndpoint(
          account: $account
          deploymentType: $deploymentType
          folderName: $folderName
          endpointName: $endpointName
          adminkey: $adminkey
        ) {
          account_name
          folder_name
          endpoint_name
          updated_at
        }
      }"""
        )
        account = self.login.account
        admin_key = self.login.admin_key
        gql_vars = {
            "account": account,
            "adminkey": admin_key,
            "deploymentType": "local",
            "folderName": parts[0],
            "endpointName": parts[1],
        }
        logger.debug(f"stepzen services delete {endpoint_name}")
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)
        except TransportQueryError as e:
            print(
                "An unexpected error occurred while deploying to the API Connect Essentials server and removing an intermediate work prduct",
                file=sys.stderr,
            )
            report_transport_error(e, reportLocation=False)
            raise RuntimeError("error deploying " + str(e))
        logger.debug(f"zenctl: removeEndpoint {time.time() - start}")
        operation = "removeEndpoint"
        if not result or operation not in result:
            logger.debug(f"Failure {result}")
            raise RuntimeError(f"deletion of endpoint {endpoint_name} failed")
        gql_out = result.get(operation)
        if not gql_out:
            raise RuntimeError(f"deletion of endpoint {endpoint_name} failed")

        # paranoid check
        # removing due to issues with vcr testing.
        # if not any([acc["account_name"] == account for acc in gql_out]):
        #    raise RuntimeError(f"deletion of endpoint {endpoint_name} failed")
        if len(gql_out) < 1:
            raise RuntimeError(f"deletion of endpoint {endpoint_name} failed")
        return f"{endpoint_name}"

    async def deploy(
        self,
        endpoint_name: str,
        endpoint_schema: EndpointSchema,
        config: Optional[StepzenConfig],
        keep_configuration_raw: bool = False,
    ) -> StepzenDeployResult:
        """
        stepzen deploy
        """
        query = gql(
            """mutation (
  $account: String! $adminKey: String!
  $folderName: String! $endpointName: String!
  $schemaFiles: SchemaFilesInput! $configuration: Configuration
  $deploymentType: String! $public: Boolean! $endpointType: String!
) {
  endpoints: addEndpoint(
    account: $account adminkey: $adminKey
    folderName: $folderName endpointName: $endpointName
    schemaFiles: $schemaFiles configuration: $configuration
    deploymentType: $deploymentType public: $public endpointType: $endpointType
  ) {
    account: account_name
    folderName: folder_name
    endpointName: endpoint_name
    public: endpoint_public
    endpointType: endpoint_type
    deploymentType: deployment_type
    createdAt: created_at
    updatedAt: updated_at
  }
}"""
        )
        sfiles = endpoint_schema.schema_files()
        parts = endpoint_name.split("/")  # check?
        admin_key = self.login.admin_key
        gql_vars = {
            "account": self.login.account,
            "deploymentType": "local",
            "folderName": parts[0],
            "endpointName": parts[1],
            "public": False,
            "endpointType": "dev",  # not in use yet.
            "schemaFiles": sfiles,
            "adminKey": admin_key,
        }

        # edge case.  Best to leave out configuration if it is missing, zenctl2 does not like null or {}
        cdata = (
            (config.data if keep_configuration_raw else config.get_configuration())
            if config
            else None
        )
        if cdata:
            # limit to input Configuration
            gql_vars["configuration"] = {
                k: v
                for k, v in cdata.items()
                if k in ["configurationset", "ruleset", "access", "deployment"]
            }

        logger.debug(
            f'stepzen services deploy {endpoint_name} [{len(gql_vars["schemaFiles"].get("files"))}]'
        )
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)
        except TransportQueryError as e:
            print(
                "An error occurred while deploying to the API Connect Essentials server",
                file=sys.stderr,
            )
            report_transport_error(e)
            raise RuntimeError("error deploying " + str(e))

        logger.debug(f"stepzen services deploy {endpoint_name}: took {time.time() - start}")
        if not result or "endpoints" not in result or not result["endpoints"]:
            logger.debug(f"Failure {result}")
            raise RuntimeError("deploy failed")
        return StepzenDeployResult(result, self.login.domain)


class IntrospectionMessage:
    """message as returned by introspection"""

    def __init__(self, level: str, message: str, location: str):
        # technically, level is an enum of Error, Info, Warning but this is good enough.
        self.level = level
        self.message = message
        self.location = location

    def __str__(self):
        return f"{self.level}: {self.message}\n{self.location}"


class IntrospectionSDLForFlowResult:
    """sdlForFlow results"""

    @classmethod
    def build_messages(
        cls, messages: List[Dict[str, Union[str, List[str]]]]
    ) -> List[IntrospectionMessage]:
        # level: MessageLevel!
        # message: String!
        # location: String
        if not messages:
            return []
        result: List[IntrospectionMessage] = []
        for message in messages:
            if not isinstance(message, dict):
                continue
            # all of these are required, so the location double check should not be required...
            if not isinstance(message["level"], str):
                logger.debug("introspection message: level is not a string")
                continue
            if not isinstance(message["message"], str):
                logger.debug("introspection message: message is not a string")
                continue

            ilocation = message.get("location")
            if not isinstance(ilocation, str):
                logger.debug("introspection message: location is not a str")
                ilocation = ""
            else:
                if ilocation == "<undefined position>":  # mask this out?
                    ilocation = ""
            imess = IntrospectionMessage(message["level"], message["message"], ilocation)
            result.append(imess)
        return result

    def __init__(self, sdlForFlowResult: Optional[Dict[str, Any]]):
        self.sdl = ""
        self.messages = []
        self.numberOfFlows = 0
        self.flowNames = []
        if not sdlForFlowResult:
            return
        if "sdl" not in sdlForFlowResult:
            return

        # controlled copy
        if sdlForFlowResult["sdl"] is None or isinstance(sdlForFlowResult["sdl"], str):
            self.sdl: Optional[str] = sdlForFlowResult["sdl"]
        else:
            # superfluous in reality since sdlForflow will never do this.
            raise RuntimeError("internal error: sdlForFlow returned a non-string type for the SDL")

        self.messages = self.build_messages(sdlForFlowResult.get("messages", []))

        # allow count to be set in the (near) future
        # self.count: Optional[int] = None
        if "summary" in sdlForFlowResult:
            summary = sdlForFlowResult["summary"]
            self.summary = summary  # forward this for now?
            self.numberOfFlows = summary.get("numberOfFlows", 0)  # optional INTenral
            self.flowNames = []
            check = summary.get("flowNames", [])

            # a bit too much of a check perhaps?
            def isokay(check):
                if not isinstance(check, list):
                    return False
                for val in check:
                    if not isinstance(val, str):
                        return False
                return True

            if isokay(check):
                self.flowNames = check


class IntrospectionServices:
    """
    introspection services
    - depending on end to end testing for this for now.
    """

    def __init__(self, login: StepzenLogin):
        headers = {}
        self.introspection = login.introspection
        self.login = login  # for checking for local
        # hostname to use in local redirection for containers
        self.localredirecthost = "host.docker.internal"
        if not self.introspection:
            raise RuntimeError("internal error: Missing zenctl2 address")
        logger.debug(f"IntrospectionServices: {self.introspection}")
        httpx_transport = AsyncHTTPTransport(retries=3)
        self.transport = HTTPXAsyncTransport(
            url=self.introspection,
            headers=headers,
            transport=httpx_transport,
            follow_redirects=True,
        )

    @staticmethod
    def apikey_header(
        apikey: Optional[str], headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        # return as dict instead of HeaderInput
        if not headers:
            headers = {}
        if not apikey:
            return headers
        headers.update({"Authorization": f"apikey {apikey}"})
        return headers

    @staticmethod
    def to_header_input(headers: Dict[str, str]) -> List[Dict[str, str]]:
        """
        header is { "header-Name", "value", ....}
        introspection uses [HeaderInput] where
        HeaderInput = {"name" : "header-name", "value": "value"}
        q: should we create the type since other gql services do the same?
        """
        if not headers:
            return []
        return [{"name": k, "value": v} for k, v in headers.items()]

    async def validate(self):
        """for now - just do a quick check by retrieving the schema"""
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=True, execute_timeout=60
            ):
                pass
        except ConnectError as e:
            logger.debug(f"Unable to connect to the introspection url {self.introspection}: {e}")
            raise RuntimeError(
                f"Unable to connect to the introspection url {self.introspection}: {e}"
            )
        except RuntimeError as e:
            logger.debug(f"Unable to validate the introspection url {self.introspection}: {e}")
            raise RuntimeError(
                f"Unable to validate the introspection url {self.introspection}: {e}"
            )

    def adjust_uri(self, uri: str) -> str:
        """
        introspection needs the host.docker.internal address when running as local containers
        """
        if self.login.as_stepzen_service:
            theurl = urlparse(uri)
            # check if the incoming URL is destined for the local service
            # and if so use host.docker.internal  in lieu of 127.0.0.1
            if (
                theurl.scheme == "http"
                and theurl.hostname == self.login.self_host
                and theurl.port == self.login.self_port
            ):
                newuri = urlunsplit(
                    (
                        theurl.scheme,
                        f"{self.localredirecthost}:{self.login.self_port}",  # rewrite netloc/authority
                        theurl.path,
                        theurl.query,
                        theurl.fragment,
                    )
                )
                logger.debug(
                    f"{uri} is a local service address, rewriting for container as {newuri}"
                )
                return newuri
        return uri

    async def import_graphql(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,  # NYI
        prefix: Optional[str] = None,
    ) -> str:
        query = gql(
            """query (  $endpoint: String! 
  $typePrefix: String $includeRootOperations: Boolean
  $headers: [HeaderInput!]
) {
  getSDLFromGraphQL( endpoint: $endpoint
    typePrefix: $typePrefix includeRootOperations: $includeRootOperations
    headers: $headers
  ) { sdl config } }
"""
        )
        gql_vars: Dict[str, Union[str, List[Dict[str, str]]]] = {
            "endpoint": self.adjust_uri(endpoint),
        }
        if headers:
            gql_vars["headers"] = self.to_header_input(headers)

        # LATER: includeRootOperations if needed
        if prefix:
            logger.debug(f"graphql_import: typePrefix {prefix}")
            gql_vars["typePrefix"] = prefix
        logger.debug("introspection services deploy importGraphQL")
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)
        except TransportQueryError as e:
            print(
                f"An error occurred while importing the GraphQL endpoint {endpoint}",
                file=sys.stderr,
            )
            report_transport_error(e, reportLocation=False)
            raise RuntimeError("error deploying " + str(e))
        logger.debug(f"importGraphQL:  {time.time() - start}")
        if not result or "getSDLFromGraphQL" not in result:
            raise RuntimeError("import_graphql failed")
        # LATER: figure out if we need to handle config
        return result["getSDLFromGraphQL"]["sdl"]

    async def import_openapi_schema(
        self,
        tag: str,
        schema: str,
        prefix: Optional[str] = None,
    ) -> Tuple[Optional[str], Optional[str]]:
        query = gql(
            """query sdlForOpenAPIInline($schema: String!, $options: OpenAPIIntrospectionOptionsInput) {
  sdlForOpenAPIInline(schema: $schema, options: $options) {
    sdl
    config
  }
}"""
        )
        gql_vars: Dict[str, Union[str, Dict[str, str]]] = {
            "schema": schema,
        }

        # Missing: typeNullability: AlwaysNullable, InferWithNonNullableDefault, InferWithNullableDefault
        #          onInvalidGraphQLIdentifier: OmitField SetParentTypeToJSON
        logger.debug(f"graphql_openapi: typePrefix {prefix}")
        if prefix:
            gql_vars["options"] = {"typePrefix": prefix}
        logger.debug("introspection services deploy openapi")
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)
        except TransportQueryError as e:
            print(
                f"An error occurred while importing the OpenAPI {tag}",
                file=sys.stderr,
            )
            report_transport_error(e, reportLocation=False)
            raise RuntimeError("error deploying " + str(e))
        logger.debug(f"importOpenAPI:  {time.time() - start}")
        if not result or "sdlForOpenAPIInline" not in result:
            raise RuntimeError("import_OpenAPI failed")
        # LATER: figure out if we need to handle config
        sdlandconfig = result["sdlForOpenAPIInline"]
        return sdlandconfig.get("sdl"), sdlandconfig.get("config")

    async def sdlForFlow(
        self, endpoint: str, headers: Optional[Dict[str, str]], flow: str
    ) -> IntrospectionSDLForFlowResult:
        """given endpoint create flows"""

        # remove path and location from messages since there is a breaking introspection graphql change
        # revise after settle time.
        messages_fields = "level message"  # disable location until new itrospection goes live
        next_gen = True
        query = gql(
            """query ( $source: FlowDataSourceInput! ) { sdlForFlow(source: $source) {"""
            """ sdl  messages { """
            f"{messages_fields}"
            """ }} }"""
        )
        if next_gen:
            query = gql(
                """query ( $source: FlowDataSourceInput! ) { sdlForFlow(source: $source) {"""
                """ sdl summary { numberOfFlows flowNames } messages { """
                "level message location "
                f"{messages_fields}"
                """ }} }"""
            )
        gql_vars: Dict[str, Dict[str, Union[str, List[Dict[str, str]]]]] = {
            "source": {
                "flow": flow,
                "endpoint": self.adjust_uri(endpoint),
            }
        }
        if headers:
            gql_vars["source"]["headers"] = self.to_header_input(headers)

        logger.debug("introspection services deploy sdlForFlow")
        start = time.time()
        try:
            async with Client(
                transport=self.transport, fetch_schema_from_transport=False, execute_timeout=60
            ) as client:
                result = await client.execute(query, variable_values=gql_vars)

        except TransportQueryError as e:
            # introspection is throwing an error for EOF
            if e.errors and len(e.errors) == 1 and e.errors[0].get("message") == "end of input":
                return IntrospectionSDLForFlowResult({})

            print(f"An error occurred while deploying the flow:\n{flow}", file=sys.stderr)
            report_transport_error(e, reportLocation=False)
            raise RuntimeError("error deploying " + str(e))
        logger.debug(f"sdlForFlow:  {time.time() - start}")
        if not result or "sdlForFlow" not in result:
            raise RuntimeError("import_graphql failed")
        # can be empty
        return IntrospectionSDLForFlowResult(result.get("sdlForFlow"))


def findflow(flows: List[str]) -> int:
    """temp: remove this once introspection does the needful and returns
    "" or null for empty flows case instead of error

    """
    total = 0
    commented = 0
    uncommented = 0
    blank = 0
    for l in "\n".join(flows).split("\n"):
        ll = l.strip()
        if len(ll) >= 2 and ll[0:2] == "//":
            commented += 1
        else:
            uncommented += 1
            if not ll:
                blank += 1
        total += len(l)
    return uncommented - blank


class DeploymentResult:
    """
    deployment deploy result has a StepzenDeployResult and information from introspection.
    """

    def __init__(
        self,
        stepzen_deploy: Optional[StepzenDeployResult],
        introspection_flows: Optional[IntrospectionSDLForFlowResult],
    ):
        self.stepzen_deploy = stepzen_deploy
        self.introspection_flows = introspection_flows

    def introspection_messages(self) -> List[IntrospectionMessage]:
        if self.introspection_flows is None:
            return []
        return self.introspection_flows.messages

    def flows_count(self) -> int:
        if self.introspection_flows:
            return self.introspection_flows.numberOfFlows
        return 0

    def flows_names(self) -> List[str]:
        if self.introspection_flows:
            return self.introspection_flows.flowNames
        return []


class Deployment:
    def __init__(
        self,
        login: StepzenLogin,
        endpoint_schema: EndpointSchema,
        configurationset: Optional[StepzenConfig],
    ):
        self.login = login
        self.configurationset = configurationset
        self.endpoint_schema = endpoint_schema
        self.paranoid = False

    async def genFlows(
        self, stepzen: StepzenServices, endpoint_name: str, flows: List[str]
    ) -> IntrospectionSDLForFlowResult:
        base_endpoint_name = endpoint_name + "-base"
        endpoint_uri = stepzen.endpoint_uri(base_endpoint_name)
        logger.info(f"Deployment uri {endpoint_uri} will be presented to introspection")
        # keep_configuration_raw could be used to mask the base endpoint's configuration
        # per a though for #830 but it's not particularly helpful so avoid.
        result = await stepzen.deploy(
            base_endpoint_name,
            self.endpoint_schema,
            self.configurationset,
            keep_configuration_raw=False,  # no subs
        )
        try:
            introspection = IntrospectionServices(self.login)
            flow_definition_code = "\n".join(flows)
            sdlForFlowResult = await introspection.sdlForFlow(
                endpoint_uri,
                introspection.apikey_header(self.login.admin_key),
                flow_definition_code,
            )
            flowsdl = sdlForFlowResult.sdl
            if flowsdl is not None:
                # note: we modify the schema on the fly
                logger.debug(f"Flows added '{flowsdl}'")
                self.endpoint_schema.add(SchemaFileData("generated_flows.graphql", flowsdl))
            else:
                logger.debug("Empty SDL from introspection")
            return sdlForFlowResult
        finally:
            # this could be done in parallel with last deploy
            logger.debug(f"removing {base_endpoint_name}")
            result = await stepzen.remove_endpoint(base_endpoint_name)
            logger.debug(f"removed {result}")

    async def deploy(
        self,
        endpoint_name: str,
        flows: List[str],
    ) -> DeploymentResult:
        start = time.time()
        # validate login
        stepzen = StepzenServices(self.login)
        if self.paranoid:
            _ = await stepzen.validate()

        sdlForFlowResult: Optional[IntrospectionSDLForFlowResult] = None
        if len(flows):
            # modifies self.endpoint_schema
            sdlForFlowResult = await self.genFlows(stepzen, endpoint_name, flows)
            if sdlForFlowResult.sdl is None:
                # this can happen for EOF or because there was an error....
                # check to see if there are any errors.
                # previously check to see if there was an Error with EOF...
                if len(sdlForFlowResult.messages):
                    for msg in sdlForFlowResult.messages:
                        # an error was seen, so assume there is a problem that prevented
                        # the SDL from being generated rather than some begnign issue
                        if msg.level == "Error":
                            return DeploymentResult(None, sdlForFlowResult)
        deploy_result = await stepzen.deploy(
            endpoint_name, self.endpoint_schema, self.configurationset
        )
        logger.info(f"Deployment deploy: took: {time.time()-start}")
        return DeploymentResult(deploy_result, sdlForFlowResult)
