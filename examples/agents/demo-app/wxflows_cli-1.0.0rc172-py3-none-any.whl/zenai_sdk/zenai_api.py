# Copyright IBM Corp. 2023, 2024

"""
stepzen.zenai API
"""
import copy
import json
import logging
import sys
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from gql import Client, gql
from gql.transport.exceptions import TransportQueryError
from gql.transport.httpx import HTTPXAsyncTransport
from graphql import DocumentNode, ExecutionResult
from graphql.error.graphql_error import GraphQLError
from httpx import AsyncHTTPTransport

from .cli_error import CLIError
from .configuration import Configuration

logger = logging.getLogger("wxflows")


class ZenaiUtils:  # pylint: disable=too-few-public-methods
    """Utilities for zenai"""

    @staticmethod
    def check_object(path):
        """simple checks if a file is TSV that fits current assumptions"""
        chunking = 500
        tsv = pd.read_csv(
            path, sep="\t", escapechar="\\", header=0, iterator=True, chunksize=chunking
        )
        for chunk in tsv:
            missed = set(["id", "text", "title"]) - set(chunk.columns.tolist())
            if missed:
                raise CLIError(f"Missing columns {missed}")
            break  # first only


def report_transport_error(e: TransportQueryError):
    if e.errors:
        for err in e.errors:
            print("  Message ", err.get("message"), file=sys.stderr)
            print("  Location", err.get("locations"), file=sys.stderr)
    if e.extensions:
        print(e.extensions, file=sys.stderr)


class AsyncZenUpload:
    """
    api calls
    """

    def __init__(
        self,
        account: str,
        apikey: str,
        authorization: str,
        endpoint: str,
        ai_engine: str,
        default_model="sentence-transformers/all-minilm-l6-v2",
    ):
        """init"""
        self.account = account
        # apikey normally
        self.authorization = "APIKey " + authorization
        self.apikey = f"APIKey {apikey}"
        self.endpoint = endpoint
        self.ai_engine = ai_engine
        if self.ai_engine == Configuration.BAM:
            # bam has a limit of 20 total items being processed for embeddings at a time
            # so we limit the number we process to 90% in order to provide
            # a buffer for other usage.
            self.call_quota = 20
            self.call_limit = 18  # 90%
        elif self.ai_engine == Configuration.WATSONX_AI:
            # watsonx has a limit of 1000 per call
            self.call_quota = 1000
            self.call_limit = 1000
        else:
            self.call_limit = 100  # some reasonable number
        self.default_model = default_model
        self.admin_headers = {
            "Authorization": self.authorization,
            "Content-Type": "application/json",
        }
        self.headers = {
            "Authorization": self.apikey,
            "Content-Type": "application/json",
        }
        self.debug_extra_headers = {
            "StepZen-Debug-Authorization": f"apikey {authorization}",
            "Stepzen-Debug-Level": "1",
            "x-graphql-analytics-enabled": "true",
        }

    def ai_engine_name(self) -> str:
        return str(self.ai_engine)

    async def graphql(
        self,
        query: DocumentNode,
        operationName: str,
        variables: Any,
        use_admin_key: bool = False,
        extra_headers: Optional[Dict[str, str]] = None,
        fetch_schema: bool = False,
        raise_error_instead: bool = True,
        debug: bool = False,
    ) -> ExecutionResult:
        result = await self._graphql(
            query,
            operationName,
            variables,
            use_admin_key,
            extra_headers,
            fetch_schema,
            raise_error_instead,
            debug=debug,
            get_execution_result=True,
        )
        if not isinstance(result, ExecutionResult):
            raise Exception("Internal error: Missing ExecutionResult returned")
        return result

    async def _graphql(
        self,
        query: DocumentNode,
        operationName: str,
        variables: Any,
        use_admin_key: bool = False,
        extra_headers: Optional[Dict[str, str]] = None,
        fetch_schema: bool = False,
        raise_error_instead: bool = False,
        get_execution_result: bool = False,
        debug: bool = False,
    ) -> Union[Dict[str, Any], ExecutionResult]:
        """
        compute emedding for a text
        """
        gql_vars = variables
        if use_admin_key:
            headers = copy.copy(self.admin_headers)
        else:
            headers = copy.copy(self.headers)
        if extra_headers:
            headers.update(extra_headers)

        if debug:
            headers.update(self.debug_extra_headers)

        # figure out how to, if we can share the AsyncHTTPTransport later.
        transport = HTTPXAsyncTransport(
            url=self.endpoint, headers=headers, transport=AsyncHTTPTransport(retries=3)
        )
        client = Client(
            transport=transport,
            fetch_schema_from_transport=fetch_schema,
            execute_timeout=60,
        )
        try:
            async with client as session:
                result = await session.execute(
                    query,
                    operation_name=operationName,
                    variable_values=gql_vars,
                    get_execution_result=get_execution_result,
                    extra_args={"timeout": 60},
                )
            # side effect for now.
            if fetch_schema:
                self.client_schema = client.schema
        except TransportQueryError as e:
            logger.debug(
                f"graphql - TransportQueryError Exception  {e} raise {raise_error_instead}"
            )
            if raise_error_instead:
                if e.extensions:
                    logger.debug(f"graphql - extensions {json.dumps(e.extensions,indent=4)}")
                raise
            print(f"An error occurred while executing {operationName}", file=sys.stderr)
            report_transport_error(e)
            raise RuntimeError("error deploying " + str(e))
        except GraphQLError as e:
            logger.debug(f"graphql - GraphQLError Exception  {e}")
            raise
        except Exception as e:
            logger.debug(f"graphql - Exception  {e}")
            raise
        finally:
            # client schema  is valid on many error paths so pass it through
            # but a smarter way would be nice?
            try:
                if fetch_schema:
                    self.client_schema = client.schema
            except AttributeError:
                # ignore such
                pass

        return result

    async def compute_embedding(
        self,
        text: List[str],
        model: Optional[str] = None,
    ) -> Optional[List[List[float]]]:
        """
        compute emedding for a text
        result can be empty
        """
        if not model:
            model = self.default_model
        if model == "mini":
            model = "sentence-transformers/all-minilm-l6-v2"

        if len(text) > self.call_limit:
            raise Exception("Too many requests error may occur, not allowing")

        # call embeddings ignore aiModel and let that default
        # AIEngine should be moved from a enum to a string to allow extensions
        q = gql(
            "query ce($inputs: [String!]! $model: String! $engine: AIEngine!) "
            "{ embeddings(inputs: $inputs model: $model aiEngine:$engine) { embeddings } }"
        )
        vars = {"inputs": text, "model": model, "engine": self.ai_engine}
        try:
            # this currently requires an admin key...
            res = await self._graphql(q, "ce", vars, use_admin_key=True, raise_error_instead=True)
        except TransportQueryError as e:
            if e.errors and len(e.errors):
                for err in e.errors:
                    if err.get("path") == ["embeddings"]:
                        if err.get("message").startswith("Connector: HTTP Error: Bad Request"):
                            raise RuntimeError(
                                "embeddings failed, requested too many embeddings.  Internal error."
                            )
                        elif err.get("message").startswith("Connector: HTTP Error: Not Found"):
                            raise RuntimeError("embeddings failed, likely bad model name")
                        elif err.get("message").startswith(
                            "Connector: HTTP Error: Too Many Requests"
                        ):
                            raise RuntimeError("embeddings failed, too many requests outstanding")
            raise
        if isinstance(res, ExecutionResult):
            raise Exception(
                "Error while retrieving embeddings: unsupported ai_system, too many calls outstanding or another issue."
            )
        if not res:
            raise Exception("Unspecified error while retrieving embeddings")
        if res.get("embeddings") is None:
            raise Exception(
                "Error while retrieving embeddings: unsupported ai_system, too many calls outstanding or another issue."
            )
        return res.get("embeddings", {}).get("embeddings")
